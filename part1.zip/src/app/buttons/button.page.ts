import { Component } from '@angular/core';
import { Flashlight } from '@ionic-native/flashlight/ngx';
import { NativeAudio } from '@ionic-native/native-audio/ngx';
@Component({
  selector: 'app-button',
  templateUrl: 'button.page.html',
  styleUrls: ['button.page.scss']
})
export class buttonPage {
	
	
	toogle:boolean=false;
	light:boolean=false;

	constructor(private flashlight: Flashlight,private nativeaudio: NativeAudio) { }
	
	playSound(){
		
		if(this.toogle){
			this.nativeaudio.preloadSimple('sqeak', 'assets/audio/sqeak.mp3')
			this.nativeaudio.play('sqeak');
			this.toogle=false;
		}else{
			this.nativeaudio.preloadSimple('boing', 'assets/audio/boing.mp3')
			this.nativeaudio.play('boing');
			this.toogle=true;
			
		}
		
	}
	
	
	turnOnflashLight(){
		console.log("flash light");
		if(this.light){
			this.flashlight.switchOff();
			this.light=false;
		}else{
			this.light=true;
			this.flashlight.switchOn();
		}
	}
	
	
}
