import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';

const routes: Routes = [
  {
    path: 'tabs',
    component: TabsPage,
    children: [
      {
        path: 'device',
        children: [
          {
            path: '',
            loadChildren: '../device/device.module#devicePageModule'
          }
        ]
      },
      {
        path: 'motion',
        children: [
          {
            path: '',
            loadChildren: '../Motion/motion.module#motionPageModule'
          }
        ]
      },
      {
        path: 'buttons',
        children: [
          {
            path: '',
            loadChildren: '../buttons/button.module#buttonPageModule'
          }
        ]
      },
      {
        path: '',
        redirectTo: '/tabs/device',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/tabs/device',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class TabsPageRoutingModule {}
