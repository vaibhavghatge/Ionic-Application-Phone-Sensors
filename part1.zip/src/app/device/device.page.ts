import { Component } from '@angular/core';
import { Device } from '@ionic-native/device/ngx';
@Component({
  selector: 'app-device',
  templateUrl: 'device.page.html',
  styleUrls: ['device.page.scss']
})
export class devicePage {
	modelname:string;
	platform:string;
	manufacturer:string;
	version:string;
	serial:string;
	uuid:string;
	virtual:boolean ;
	constructor(private device: Device) { 
		this.modelname=device.model;
		this.platform=device.platform;
		this.manufacturer=device.manufacturer;
		this.uuid=device.uuid;
		this.version=device.version;
		this.virtual=device.isVirtual;
		this.serial=device.serial;
		console.log(device);
	}

	
}
