import { Component } from '@angular/core';
import { DeviceOrientation, DeviceOrientationCompassHeading } from '@ionic-native/device-orientation';
import { DeviceMotion, DeviceMotionAccelerationData } from '@ionic-native/device-motion/ngx';
import { Shake } from '@ionic-native/shake/ngx';
import { Vibration } from '@ionic-native/vibration/ngx';

@Component({
  selector: 'app-motion',
  templateUrl: 'motion.page.html',
  styleUrls: ['motion.page.scss']
})
export class motionPage {
	
	x:number;
	y:number;
	z:number;
	constructor(private device: DeviceMotion,private vibration: Vibration,private shake: Shake) { 
		// Watch device acceleration
			var subscription = this.device.watchAcceleration().subscribe((acceleration: DeviceMotionAccelerationData) => {
			  this.x=acceleration.x;
			  this.y=acceleration.y;
			  this.z=acceleration.z;
			  
			});
			
			 const watch = this.shake.startWatch(60).subscribe(() => {
				this.vibration.vibrate(1000);
			});
			
	}
	
	
 
	
	
}
